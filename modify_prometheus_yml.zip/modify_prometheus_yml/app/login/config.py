#encoding=utf-8
SECRET_KEY = 'jklklsadhfjkhwbii9/sdf\sdf'
db_config = {
        'db_host': '10.12.3.5',
        'db_port': 3306,
        'db_user': 'root',
        'db_pwd': '12345678',
        'database': 'management'
    }
